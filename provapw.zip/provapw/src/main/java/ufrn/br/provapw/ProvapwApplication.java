package ufrn.br.provapw;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@SpringBootApplication
public class ProvapwApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProvapwApplication.class, args);

	}
	@Controller
    public class CadastroPessoa {
        
        private static List<Usuario> usuariosCadastrados = new ArrayList<>();

        @GetMapping("/cadastro")
        public void getCadastro(HttpServletRequest request,HttpServletResponse response) throws IOException {
            response.setContentType("text/html");
            var writer = response.getWriter();

			String erro = request.getParameter("erro");
    		String sucesso = request.getParameter("sucesso");

			HttpSession session = request.getSession(false);

			writer.println("<html><head><title>Cadastro</title></head>");

			if ("email_duplicado".equals(erro)) {
				writer.println("<p>Erro: Email já cadastrado.</p>");
			}

			if ("true".equals(sucesso)) {
				writer.println("<p>Cadastro realizado com sucesso!</p>");
			}

			if (session != null && session.getAttribute("usuarioAutenticado") != null) {
                Usuario usuario = (Usuario) session.getAttribute("usuarioAutenticado");
                writer.println("<p>Usuário autenticado: " + usuario.getEmail() + "</p>");
            }
			
			writer.println("<body>Cadastro");
            writer.println("<form action='/cadastro' method='post'>");
            writer.println("Email: <input type='text' name='email'/><br/>");
            writer.println("Senha: <input type='text' name='senha'/><br/>");
            writer.println("<input type='submit' value='Enviar'/>");
            writer.println("</form>");
            writer.println("</body>");
            writer.println("</html>");
            writer.close();
			
		}

		@PostMapping("/cadastro")
        public void postCadastro(@RequestParam String email, @RequestParam String senha, HttpServletRequest request, HttpServletResponse response) throws IOException {
            for (Usuario usuario : usuariosCadastrados) {
                if (usuario.getEmail().equalsIgnoreCase(email)) { 
                    response.sendRedirect("/cadastro?erro=email_duplicado");
                    return;
                }
            }

			Usuario novoUsuario = new Usuario(email, senha);
            usuariosCadastrados.add(novoUsuario);

			HttpSession session = request.getSession(true);
            session.setAttribute("usuarioAutenticado", novoUsuario);

			String sessionId = session.getId();
			jakarta.servlet.http.Cookie sessionCookie = new jakarta.servlet.http.Cookie("SESSION_ID", sessionId);
			sessionCookie.setPath("/"); 
			sessionCookie.setHttpOnly(true); 
			response.addCookie(sessionCookie);
           
            response.sendRedirect("/dashboard");
		}

		@GetMapping("/dashboard")
        public void getTela(HttpServletRequest request,HttpServletResponse response) throws IOException {
            response.setContentType("text/html");
            var writer = response.getWriter();

			writer.println("<html><head><title>Nova Tela</title></head>");
			writer.println("<body>DASHBOARD</body>");
			writer.println("</html>");


            writer.close();
        }

	}
}


package ufrn.br.provapw;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProvapwApplicationTests {

	@Test
	void contextLoads() {
	}

}
